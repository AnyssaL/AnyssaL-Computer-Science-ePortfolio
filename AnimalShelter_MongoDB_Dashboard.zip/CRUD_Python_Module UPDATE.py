# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self):
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER ='aacuser1' 
        PASS = '********' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals'
        #
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement create in CRUD. 
    def create(self, data):
        if data is not None: 
            self.database.animals.insert_one(data) 
            return True
            # data should be dictionary             
        else: 
            raise Exception("Nothing to save, because data parameter is empty") 

    # Create method to implement read in CRUD.
    # find query to return list
    # if no list is found, else return empty list
    def read(self, query):
        if query is not None:
            self.database.animals.find(query)
            return list(self.database.animals.find(query))
        else:
            raise Exception("Error reading data")
            return []
                 
    # Update method to implement Update in CRUD        
    def Update(self, query, update_data):
        if data is not None:
            updated_count = self.database.animals.update_many(query, update_data)
            return updated_count.modified_count
        else:
            raise Exception("Error updating data")
            return 0
        
    # Update method to implement delete in CRUD  
    def Delete(self, query):
        if data is not None:
            delete_result = self.database.animals.delete_many(query)
            return delete_result.deleted_count
        else:
            raise Exception("Error deleting data")
            return 0